//(function() {
		
 

   // function SortProduct() {       
        
       /*
function sort() {
    var list, i, switching, b, shouldSwitch;
    list = document.getElementById("01");
    switching = true;
    while (switching) {
      switching = false;
      b = list.getElementsByTagName("li");
      for (i = 0; i < (b.length - 1); i++) {
        shouldSwitch = false;
        if (b[i].innerHTML.toLowerCase() > b[i + 1].innerHTML.toLowerCase()) {
          shouldSwitch = true;
          break;
        }
      }
      if (shouldSwitch) {
        b[i].parentNode.insertBefore(b[i + 1], b[i]);
        switching = true;
      }
    }
  }
  */
  
  function hideDepartment(displayValue) {
                    var x = document.querySelectorAll(".suite-title");
                    for (let i of x) {
                      i.style.display = displayValue;
                    }
                  }
        
  function sortBy(sortBy){
    let field = document.querySelectorAll('.card-container');
    let li = [];
     for(let i=0; i < field.length; i++ ){
        li = li.length > 0 ? li.concat(Array.from(field[i].children)) : Array.from(field[i].children);
    }
    let ar = [];
    for(let i of li){
        const drName = i.children[1];
        const x = drName.textContent.trim();
        i.setAttribute("dr-name", x);
        ar.push(i);
    }   

            if(sortBy == 1) // Alphabetically
            {
                hideDepartment("none");
              
                 
                let sortli = li.sort(function( a, b ) {
                    const ax = a.getAttribute('dr-name').toLowerCase();
                    const bx = b.getAttribute('dr-name').toLowerCase();
                    return ax < bx ?  -1 : ax > bx? 1 : 0;
                  });
                  let size = sortli.length /field.length;
                  let startIndex = 0;
                  for(let i=0; i < field.length; i++ ){
    
                     while (field[i].firstChild) {field[i].removeChild(field[i].firstChild);}
                     field[i].append(...sortli.slice(startIndex, (startIndex + size)));	
                     startIndex+= size;
                  }
            }
            else // department 
            {
                hideDepartment("block");
                let field2 = document.querySelectorAll('.suite');
                let listDep = [];
                for(let i=0; i < field2.length; i++ ){
                    listDep.push(field2[i].children[0]);
               }
               for(let i of listDep){
                const name = i.children[0];
                const x = name.textContent.trim();
                i.setAttribute("dep-Name", x);
                ar.push(i);
               }
               for(let i=0; i < field2.length; i++ ){
                let depName = field2[i].children[0].getAttribute('dep-Name');
                while (field[i].firstChild) {field[i].removeChild(field[i].firstChild);}
                 let filterList = li.filter(x=> x.children[2].textContent.trim() == depName);
                  field[i].append(...filterList);	
             }

               
                /*
                let field = document.querySelectorAll('.suite');
                let li = [];
                 for(let i=0; i < field.length; i++ ){
                    li = li.length > 0 ? li.concat(Array.from(field[i].children[0])) : Array.from(field[i].children[0]);
                }
                let ar = [];
                for(let i of li){
                    const name = i.children[0];
                    const x = name.textContent.trim();
                    i.setAttribute("dep-Name", x);
                    ar.push(i);
                }
                let sortli = li.sort(function( a, b ) {
                    const ax = a.getAttribute('dep-Name').toLowerCase();
                    const bx = b.getAttribute('dep-Name').toLowerCase();
                    return ax < bx ?  -1 : ax > bx? 1 : 0;
                  });
                  while (field.firstChild) {field.removeChild(field.firstChild);}
                 field.append(...sortli);	
                 */
            } 
        }
  //  }
//})();