  // Get all beds on page
  const beds = document.querySelectorAll('.card');
  console.log(beds)
  // Add click event listener to each bed
  beds.forEach((bed,i) => {
    
   
    if (bed.classList.contains('available')) {

        // Show form with admission date field if bed is occupied
      console.log(`form-${i+1}`)
      console.log( document.getElementById(`form-${i+1}`))
      console.log( document.getElementById(`img-${i+1}`).src)
       document.getElementById(`form-${i+1}`).innerHTML= `
        <label for="name-${i+1}">Patient name:</label>
        </br>
        <input type="text" id="name-${i+1}" name="name-${i+1}">
        </br>
        <label for="dates-${i}">discharge dates:</label>
        </br>
        <input type="date" id="dates-${i+1}" name="dates-${i+1}">
        </br>
        <button id="chick-${i+1}" class="det " >Submit</button>
    `;
        document.getElementById(`chick-${i+1}`).addEventListener("click",  () => {

            var name =document.getElementById(`name-${i+1}`).value;
            console.log(name);
            var dischargeDate =document.getElementById(`dates-${i+1}`).value;
            console.log(dischargeDate)
            if (name == "" || dischargeDate == "") {
              alert("Name and Discharge Date must be filled out");
              return false;
            }
        
          else  if (!/^[a-zA-Z ]+$/.test(name)) { 
              alert("Name must contain only letters and spaces"); 
              return false; 
            }
        
          else  if (new Date(dischargeDate) < new Date()) { 
              alert("Discharge date cannot be before today's date"); 
              return false; 
            }
            else{
                document.getElementById(`img-${i+1}`).src=`./imagepj/bed2.png`;
                console.log( document.getElementById(`form-${i+1}`).style.display);
                document.getElementById(`form-${i+1}`).style.display="none";

                               document.getElementById(`form-${i+1}`).style.width="0px";
                               document.getElementById(`form-${i+1}`).style.height="0px";
                               document.getElementById(`form-${i+1}`).style.opacity=0;
                                document.getElementById(`formm-${i+1}`).innerHTML=`
                                <label for="namee-${i+1}">Patient name:</label>
                                </br>
                                <input type="text" id="namee-${i+1}" name="namee-${i+1}" disabled value="${name}">
                                </br>
                                <label for="datess-${i+1}">discharge dates:</label>
                                </br>
                                <input type="date" id="datess-${i+1}" name="datess-${i+1}" disabled value="${dischargeDate}">
                                </br>
                                  
                                `
                                document.getElementById(`formm-${i+1}`).style.display="block";



                console.log( document.getElementById(`form-${i+1}`).style.display);
                 alert("Submitted successfully!"); 
    
            }
           
    }); 

      } else {

        // Show form without admission date field if bed is not occupied 
        document.getElementById(`form-${i+1}`).innerHTML = `<form>
        <label for="patientName">Patient Name:</label>
        </br>
        <input type="text" id="patientName" value="Ahmad" disabled>
</br>
        <label for="admissionDate">Admission Date:</label>
        </br>
        <input type="text" id="admissionDate" value="2023-3-23" disabled>
</br>
        <label for="dischargeDate">Discharge Date:</label>
        </br>
        <input type="text" id="dischargeDate" value="2023-2-23" disabled>

        
      </form>`;  

      }});


 beds.forEach((bed,i) => {
    bed.addEventListener('click', (e)=> {
       
      // Get patient name and discharge date from form
     
      
      // Check if bed is occupied or not
     {

        // Show form with admission date field if bed is occupied
      
       

        
        document.getElementById(`form-${i+1}`).style.display="block";

      } 

    }); 
  });          
