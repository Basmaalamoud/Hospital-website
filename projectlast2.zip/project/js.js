//function write_below(form)
/*{
var input = document.forms.write.input_to_write.value;
document.getElementById('write_here').innerHTML="Your input was:"+input;
return false;
}


//var info = document.getElementsByName('write');
/*var info_value;

if(input[type==Checkbox]|| input[type==radio])
for(var i = 0; i < input.length; i++){
    if(input[i].checked){
        info_value = info[i].value;
    }
	
if (document.getElementById('r1').checked) {
  rate_value = document.getElementById('r1').value;
}
	
	
var rates = document.getElementsByName('rate');
var rate_value;
for(var i = 0; i < rates.length; i++){
    if(rates[i].checked){
        rate_value = rates[i].value;
    }
	*/
	
  /* function testVariable() {
          
       var f = document.getElementByClass("myform");
        var str = '';
        for (var i = 1; i < f.length-1; i++)
      	if(input[type="Checkbox"]|| input[type="radio"]){
		   for(var k = i; i < f.length; k++)
           if(f[k].checked)
		  str = f[k].value;}
	
	str +=f[i].name + ' ' + f[i].value+ "\n";
            alert(str);
   document.getElementById('spanResult').textContent = str; }*/
		


/*function testVariable() { 
var f = document.getElementById("form1");
var y = document.getElementById("form2");
var x = document.getElementById("form3");

var str = '';
for (var i = 0; i < f.length; i++)
		if(f.type==="Checkbox"|| f.type==="radio"){
		   for(var k = i; i < f.length; k++)
           if(f[k].checked)
		  str += f[k].value;}
	str +=f[i].name + ' ' + f[i].value+ "\n";
for (var i = 0; i < y.length; i++)
	str +=y[i].name + ' ' + y[i].value+ "\n";
for (var i = 0; i < x.length-1; i++)
		if(x.type==="Checkbox"|| x.type==="radio"){
		   for(var k = i; i < x.length; k++)
           if(x[k].checked)
		  str += x[k].value;}
	str +=x[i].name + ' ' + x[i].value+ "\n";
alert(str);*/
	

/*function func() { 
var f = document.getElementByClass("myform");
var str = '';
for (var i = 1; i < f.length-1; i++){
	if(f[type==Checkbox]|| input[type==radio]){
		for(var k = i; i < f.length; k++)
         if(f[k].checked)
		 str = f[k].value;}
	str +=f[i].name + ' ' + f[i].value+ "\n";
alert(str);

	
}*/


	
	
/*function allLetter(inputtxt)
  {
   var letters = /[A-Za-z]/;
   if(inputtxt.value.match(letters))
     {
      return true;
     }
   else
     {
     alert("letters only");
     return false;
     }
  }*/
  




function testVariable() { 
var f = document.getElementById("form1");
var y = document.getElementById("form2");
var x = document.getElementById("form3");
var str=''; 

str +="First Name:"+f.fname.value+"\nLast Name:"+f.lname.value+"\nGender:"+f.G.value+"\nMarital status:"+f.mar.value;
str +="\nID:"+y.id.value+"\nMobile number:"+y.mobilenumber.value+"\nDate of birth:"+y.birthday.value+"\nSurance company:"+y.company.value;
str +="\n"+x.smoker.checked+"\n"+x.allergies.checked+"\nNote:"+x.entry.value;
//allLetter(f.fname);by Id
 var letters =/[A-Za-z]/;
 
   if (!f.fname.value){ 
   alert("first name is missing");
   }else if (f.fname.value.match(letters)){
   ; }
   else {
	 alert("invalid first name enter letters please");
     return false;
     }
	   
   if (!f.lname.value){ 
   alert("last name is missing");
   } else if (f.lname.value.match(letters)){
   ; }
   else {
	 alert("invalid last name enter letters please");
     return false;
     }
	 
   if (!f.G.value){ 
   alert("gender is missing");
   }
   if (!f.mar.value){ 
   alert("Marital status is missing");
   }
   if (!y.id.value){ 
   alert("ID is missing");
   } else if (parseInt(y.id.value)){
   ; }
   else { alert("invalid ID enter numbers please");
     return false;
     }
	   
   if (!y.mobilenumber.value){ 
   alert("Mobile number is missing");
   }else if (parseInt(y.mb.value)){
   ; }
   else { alert("invalid mobile number enter numbers please");
     return false;
     }
	 
   if (!y.birthday.value){ 
   alert("Date if birth is missing");
   }
   if (!y.company.value){ 
   alert("Surance company is missing");
   } else if (y.sc.value.match(letters)){
     var theDiv = document.getElementById("divid");
     var content = document.createTextNode(str);
     theDiv.appendChild(content);}
   else {
	 alert("invalid surance company enter letters please");
return false;}}
 
  /* if(f.fname.value.match(letters)&&f.lname.value.match(letters)&&y.sc.value.match(letters) )
     {
         ;
     }
   else
     {
     alert("letters only");
     return false;
     }*/
	 
	 /*if (parseInt(y.mb.value) && parseInt(y.id.value)) {
     var theDiv = document.getElementById("divid");
     var content = document.createTextNode(str);
     theDiv.appendChild(content);}*/
/*else {
alert("numbers only"); 
return false;}
}

/*var theDiv = document.getElementById("divid");
var content = document.createTextNode(str);
theDiv.appendChild(content);}  اكتبها عند اخر ترو*/

/*if (parseInt(y.mb.value)) {
;}
else {
alert("numbers only"); 
return false;}*/
