//if (localStorage.getItem("dark")) {
  //  var element = document.body;
   // body.classList.add("dark");
    //element.className = "dark-mode";

//}

//else if (localStorage.getItem("light"))
//  body.classList.add("light");

window.onload(themspage());
function themspage() {
    var theme = localStorage.getItem("theams");
    var element = document.body;
  //  alert(theam);


    if (theme === "dark")
        element.className = "dark-mode";
    else if (theme == "light")
        element.className = "light-mode";
    else
        element.className = "defult-mode";
}





