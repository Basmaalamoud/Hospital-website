var mL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
function getMonday(d) {
    d = new Date(d);
    var day = d.getDay()+1,
        diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
   r=new Date(d.setDate(diff));
   return `Sunday ${mL[r.getMonth()]}  ${r.getDate()}`
  }
sunday = getMonday(new Date()) ;
var para = document.createElement("p");
para.innerHTML = sunday;
document.getElementById("sun").appendChild(para);
       
      