function defaultMode() {

    var element = document.body;
    var content = document.getElementById("defulitModetext");
    element.className = "defult-mode";
    content.innerText = "Dedulit Mode is ON";
    var con = document.getElementById("LightModetext");
    con.innerText = "LightMode";
    var con = document.getElementById("DarkModetext");
    con.innerText = "DarkMode";
    localStorage.setItem("theams", "defult");

}




function darkMode() {

    var element = document.body;
    var content = document.getElementById("DarkModetext");
    element.className = "dark-mode";
    content.innerText = "Dark Mode is ON";
    var con = document.getElementById("LightModetext");
    con.innerText = "LightMode";
    var content = document.getElementById("defulitModetext");
    content.innerText = "defalutMode";
    localStorage.setItem("theams", "dark");
   // var foot = document.getElementsByTagName('footer');
   // foot[0].style = 'background-color:##d3ab9e;';
    //var na = document.getElementsByTagName('nav');
    //na[0].style = 'background-color:##ebd8d0;';



}
function lightMode() {
    var element = document.body;
    var content = document.getElementById("LightModetext");
    element.className = "light-mode";
    content.innerText = "Light Mode is ON";
    var con = document.getElementById("DarkModetext");
    con.innerText = "DarkMode";
    var content = document.getElementById("defulitModetext");
    content.innerText = "defalutMode";

    localStorage.setItem("theams", "light");
   // var di = document.getElementsByTagName('div');
    //di[0].style = 'border-color: black;';
   // var foot = document.getElementsByTagName('footer');
    //foot[0].style = 'background-color:#b8bedd;';
    //var na = document.getElementsByTagName('nav');
    //na[0].style = 'background-color:#efc3e6;';
   







}







